package execution

class Trader (var item: Valuable) {
  this.item = item
}
